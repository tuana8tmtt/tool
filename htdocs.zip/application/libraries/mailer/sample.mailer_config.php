<?php

		define('GUSER', ''); // email address
        define('GPWD', ''); // email password
        define('HOST', ''); // email server host
        define('PORT', ); // email server port

        /**
         * Gmail host smtp.gmail.com
         * Gmail port 465
         */

?>